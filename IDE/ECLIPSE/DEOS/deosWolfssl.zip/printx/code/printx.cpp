#include <deos.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <videobuf.h>
#include "printx.h"

static void *videoMemory;
static VideoStream *pV = 0;
static char BUFF[80];
static char *pPlatformResource = 0;
static 	platformResourceHandle hPlatformResource;
static size_t platResourceSize = 0;
static DWORD bytesWritten = 0;

/*
 ** FHdr-beg ****************************************************************
 **
 ** Purpose: The GCC compiler will generate calls to atexit() in order
 **          to to register static object destructors.  In our case,
 **          the statically defined pointer to a Videostream object.
 **          The Deos GCC startup library does not support atexit(),
 **          so we do it here.  In our case we are not interested in
 **          invoking any destructors.
 **
 ** FPrj-beg ****************************************************************
 **
 ** FPrj-end ****************************************************************
 ** FHdr-end ****************************************************************
 */
extern "C" {void atexit() {}}

/* ------------------------------------------------------------------------- */
extern "C" void initPrintx(const char *name)
{
  // If memory object name provided, assume it is an auto-created memory object.
  // Attach to it, and grant access.
  bool gotMo = false;
  if (name)
  {
    // Create a Memory Object, and attach to it.
	ipcMemoryObjectHandle smoHandle;
	ipcAttachedMemoryObjectHandle amoHandle;
	if (getMemoryObjectHandle(name, &smoHandle) == ipcValid)
	{
	  if (grantMemoryObjectAccess(smoHandle, currentProcessHandle(), false, readWriteAccess) == ipcValid)
	  {
	    ipcStatus s = attachMemoryObject("", smoHandle, readWriteAccess, &videoMemory, 0x1000, 0, &amoHandle);
	    if (s == ipcValid)
	    { gotMo = true; }
	  }
	}
  }

  if (gotMo)
  {
   // When using shared memory as video memory, it must be manually initialized (cleared)
   initializeVideoMemory(videoMemory);
  }
  else
  {
    // No MO so use the standard video memory
    videoMemory = (void *) CGAVideoMemoryAddress();
  }

  static VideoStream vd(0, 0, 25, 80, (noBlink | bgBlack | fgWhite), videoMemory);
  pV = &vd;
}

/* ------------------------------------------------------------------------- */
extern "C" void initPrintxP(const char *name)
{
	accessStyle unused1;

	if (attachPlatformResource("",name,&hPlatformResource,&unused1,(void **)&pPlatformResource) != resValid)
    { pPlatformResource = 0; }
	platformResourceSize(hPlatformResource,&platResourceSize);

}


/* ------------------------------------------------------------------------- */
extern "C" void printx(const char *formatString, ... )
{
	va_list varglist;

	va_start(varglist,formatString);
	vsprintf(BUFF,formatString,varglist);
	va_end(varglist);

	*pV<<BUFF;
}

/* ------------------------------------------------------------------------- */
extern "C" void printxP(const char *formatString, ... )
{
	if (!pPlatformResource)
	{ return; }

	va_list varglist;

	va_start(varglist,formatString);
	vsprintf(BUFF,formatString,varglist);
	va_end(varglist);

	bytesWritten += strlen(BUFF);
	if (bytesWritten+1 > platResourceSize)
	{ return; }

	strcpy(pPlatformResource,BUFF);
	pPlatformResource += strlen(BUFF);
}
