#ifndef PRINTX_H
#define PRINTX_H

#ifdef __cplusplus
extern "C" void initPrintx(const char *name);
extern "C" void printx(const char *formatString, ... );
extern "C" void initPrintxP(const char *name);
extern "C" void printxP(const char *formatString, ... );
#else
void initPrintx(const char *name);
void printx(const char *formatString, ... );
void initPrintxP(const char *name);
void printxP(const char *formatString, ... );
#endif

#endif //PRINTX_H
