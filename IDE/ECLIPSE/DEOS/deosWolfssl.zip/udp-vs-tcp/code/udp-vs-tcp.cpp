#include <deos.h>
#include <printx.h>
#include <tls_wolfssl.h>
#include <user_settings.h>

int main(void)
//***************************************************************************************************
// The main() thread is responsible for creating the UDP and TCP threads...that's it.  So, once these
// two threads are created, we'll delete the main thread so that it's thread budget is returned to
// slack for other processes to use.
//***************************************************************************************************
{
	// Setup for a demo of printx which uses a SMO
	initPrintx("");
	printf("TLS wolfssl example!\n");

	(void) waitUntilNextPeriod();
	 wolfsslRunTests();

	deleteThread(currentThreadHandle());
}


