#include <deos.h>
#include <printx.h>
#include <tls_wolfssl.h>
#include <user_settings.h>

int main(void)
{
	initPrintx("");
	printf("TLS wolfssl example!\n");

	(void) waitUntilNextPeriod();
	 wolfsslRunTests();

	deleteThread(currentThreadHandle());
}


