#!/usr/bin/env python

import socket
import os
import sys
import time
from socket import htons

def netTest():
  # Create and bind a  socket.
  s1 = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)   
  port = 1501
  host = '' 
  addr = (host, port)  
  while (1):
     try:
        s1.bind(addr)
        break
     except:
        pass

  PORT = 1501
  HOST = os.getenv('DESK_IP_ADDR') # Could hard code like so: '192.168.18.100'
  addr = (HOST, PORT)
  
  print "Setting up to communicate with: %s" % HOST
  
  MAX_SIZE = 128
  PROMPT = 'Type anything (less than %d characters):\n' % MAX_SIZE
  yourMessage = raw_input(PROMPT)
  s1.sendto(yourMessage, addr)

  message = s1.recv(MAX_SIZE)
  print "The target echoed:\n%s" % message
  
  s1.close()   

##
## FHdr-beg******************************************************************
##
## Purpose: The main part of the test procedure.
##
## FPrj-beg******************************************************************
##
## FPrj-end******************************************************************
## FHdr-end******************************************************************
##

# Call test procedure functions here.
netTest()
